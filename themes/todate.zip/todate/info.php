<?php
$themeName = 'todate';
$themeVirsion = '1.2.2';
$themeAuthor = 'Kulvir Singh';
$themeAuthorUrl = 'http://bit.ly/kb97';