<meta charset="UTF-8">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<meta name="title" content="<?php echo $data['title'];?>">
<meta name="description" content="<?php echo $config->meta_description;?>">
<meta name="keywords" content="<?php echo $config->meta_keywords;?>">
<link href="https://fonts.googleapis.com/css?family=Libre+Franklin:400,500&display=swap" rel="stylesheet">