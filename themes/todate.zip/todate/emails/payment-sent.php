Hello <?php echo $name ?>,
<br><br>
Your payment request of <?php echo $amount ?> is approved.
<br><br>
We have sent you money !
<br><br>
Kind regards,<br>
<?php echo $site_name ?> Team