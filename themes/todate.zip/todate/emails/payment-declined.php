Hello <?php echo $name ?>,
<br><br>
Unfortunately your payment of <?php echo $amount ?> was declined.
<br><br>
For more info, please reply to this email.
<br><br>
Kind regards,<br>
<?php echo $site_name ?> Team